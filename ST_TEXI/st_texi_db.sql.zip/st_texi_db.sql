-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 28, 2024 at 06:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `st_texi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$G/qQZlp3Z.6xa8hQmUnWhOmU/AlpFDqNN0PjIftRxsWOtMgqc6uNu');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `taxi_id` int(11) DEFAULT NULL,
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `booking_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `taxi_id`, `booking_date`, `booking_datetime`) VALUES
(9, 2, 4, '2024-02-28 16:39:05', '2024-02-29 19:00:00'),
(10, 2, 8, '2024-02-28 17:24:59', '2024-02-29 20:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(11) NOT NULL,
  `driver_name` varchar(255) NOT NULL,
  `owner_name` varchar(255) NOT NULL,
  `driver_address` varchar(255) NOT NULL,
  `owner_address` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `vehicle_serial_no` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`id`, `driver_name`, `owner_name`, `driver_address`, `owner_address`, `username`, `password`, `vehicle_serial_no`, `created_at`) VALUES
(1, 'Ayas', 'Ayas', '96,kanthala', '96,kanthala', 'driver@gmail.com', '$2y$10$gmCxWPHpSLDGf/ZsUW8uzuklmPVC1qnjLV.upQoHkBIS34ozquPCu', 'vh00010', '2024-02-28 07:02:17'),
(2, 'Ahmed', 'Ahmed', '92,kanthala', '96,kanthala', 'Ahmed@gmail.com', '$2y$10$jeaR51FBnF8QmzhqgiKK3OXlO61ODxe9CLz9seXp9mBigeBmwmwgu', 'vh00011', '2024-02-28 09:05:11'),
(3, 'shifay', 'shifay', '96,kanthala', '96,kanthala', 'shifay@gmail.com', '$2y$10$Wzur50Jz6Ox4TOjw5YKbTOCDuanPTR6t3Trohu8DvUVX5O/OCGe1O', 'vh00012', '2024-02-28 15:26:49'),
(4, 'Sharaf', 'Sharaf', '92,kanthala', '92,kanthala', 'sharaf@gmail.com', '$2y$10$ZsNGlycOTeISN1d23HzkjeaHpp58vcP4H4jsXN4ZnEJ1mC7Su0eu.', 'vh00013', '2024-02-28 17:13:12');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `message`, `timestamp`) VALUES
(5, 2, 'it is good service', '2024-02-27 16:34:31'),
(6, 2, 'you are providing good services', '2024-02-28 17:22:26');

-- --------------------------------------------------------

--
-- Table structure for table `taxis`
--

CREATE TABLE `taxis` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `availability` tinyint(1) DEFAULT 1,
  `category` varchar(50) NOT NULL,
  `vehicle_serial_no` varchar(255) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `taxis`
--

INSERT INTO `taxis` (`id`, `type`, `description`, `price`, `image_url`, `availability`, `category`, `vehicle_serial_no`, `driver_id`) VALUES
(4, 'Sedan', 'Spacious SUV for family trips', 90.00, 'uploads/Hyundai-Verna.jpg', 0, 'Car', NULL, NULL),
(8, 'Sedan', 'good', 60.00, 'uploads/sedan.jpg', 0, 'Car', NULL, NULL),
(11, 'palsur', '150Km', 100.00, 'uploads/pulsar150srilanka.png', 1, 'Bike', NULL, NULL),
(13, 'palsur', '150km', 100.00, 'uploads/pulsar150srilanka.png', 1, 'Bike', 'vh00010', 1),
(17, 'palsur', '174km', 60.00, 'uploads/pulsar150srilanka.png', 1, 'Bike', 'vh00011', 2),
(18, 'Sedan', 'good condition', 100.00, 'uploads/img3-removebg-preview.png', 1, 'Car', 'vh00012', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'sharaf', 'sharafahmed@gmail.com', '$2y$10$G/qQZlp3Z.6xa8hQmUnWhOmU/AlpFDqNN0PjIftRxsWOtMgqc6uNu'),
(2, 'user', 'user@gmail.com', '$2y$10$KNt7SfLxp0eyX7UkMIwjKOVI3qJ8/tFpsBB.FTUe2yAstf4XrLdx6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `taxi_id` (`taxi_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `taxis`
--
ALTER TABLE `taxis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_driver_id` (`driver_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `taxis`
--
ALTER TABLE `taxis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`taxi_id`) REFERENCES `taxis` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `taxis`
--
ALTER TABLE `taxis`
  ADD CONSTRAINT `fk_driver_id` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
